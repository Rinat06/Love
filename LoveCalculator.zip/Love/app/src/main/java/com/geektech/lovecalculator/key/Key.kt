package com.geektech.taskmanager.key

class Key {
    companion object {
        const val KEY_DATA = "data"
        const val KEY_ON_BOARDING = "on.boarding"
    }
}