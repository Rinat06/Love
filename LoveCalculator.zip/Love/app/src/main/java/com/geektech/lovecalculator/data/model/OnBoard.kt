package com.geektech.lovecalculator.data.model

data class OnBoard(
    var image: String,
    var title: String,
    var description: String
)
